"WEBSITE YANG BUAT HARI HARI KALIAN MANGKIN CROT"

🗣️`GIMANA CARA RECODE NYA 🤓`

bego lu ajg, nih tutornya

- fork repo (kasih star ya kontol)
- deploy ke vercel langsung
- baru recode di github supaya bisa liat live perubahan


🗣️`CARA GANTI MUSIK SPOTIFY NYA GMNA🤓`
- buat playlist terlebih dahulu
- ambil link nya dengan cara share playlist spotify itu
nah ntr link nya pasti kek gini

> ```open.spotify.com/playlist/6e5psrTK5oyi4xFRCk4MRx?si=lLrFXLfETC2jVEGzFqSnDQ%0A```

lu ambil bagian yg selesai playlist aja

berarti ambil yg ini 

> ```6e5psrTK5oyi4xFRCk4MRx```

baru di code index.tsx ganti yg url
spotify mbled nya, ganti pas id nya aja yg ada strip itu

*"dzbudzbuzrbubrz ngentot cape ngejelasin babi"*
